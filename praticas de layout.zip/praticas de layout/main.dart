import 'package:desafio2/layout1.dart';
import 'package:desafio2/layout2.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(MaterialApp(
    home: layout1(),
    //home: layout2(),
  ));
}

